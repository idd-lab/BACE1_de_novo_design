================================================================================
AUTOMATED MOLECULAR DOCKING WORKFLOW
================================================================================

OVERVIEW
This folder contains an automated, plug-and-play pipeline for high-throughput 
molecular docking. It handles ligand protonation, robust 3D embedding, receptor 
preparation, parallel docking via AutoDock Vina, and automated result extraction.

This workflow was originally developed, calibrated, and validated for the BACE1 
de novo design project by the IDD Lab.

================================================================================
CITATION & ATTRIBUTION
================================================================================
If you use this automated workflow (or modified versions of these scripts) in 
your project, thesis, or publication, please credit the pipeline by citing the 
original methodology paper:

Dang, T. T., & Luong, M. N. (2025). "A Dual-Paradigm De Novo Design Workflow: 
Exploring Chemical Space Via Parallel Ligand- and Structure-Based Approaches 
on BACE1." ChemRxiv. DOI: https://doi.org/10.26434/chemrxiv-2025-bj970

DOI: 10.26434/chemrxiv-2025-bj970
Preprint: https://chemrxiv.org/doi/full/10.26434/chemrxiv-2025-bj970
GitHub: https://github.com/idd-lab/BACE1_de_novo_design
Lab Website: https://idd-lab.github.io/

================================================================================
PREREQUISITES & ENVIRONMENT SETUP
================================================================================
To run this automated pipeline successfully, the following tools and libraries 
must be installed in your environment:

Ligand Preparation Dependencies:
- RDKit (for robust 3D coordinate embedding and minimization)
- OpenBabel (for Gasteiger charge addition and PDBQT conversion)
- Dimorphite-DL (for physiological/target pH protonation)

Receptor Preparation Dependencies:
- AutoDockTools / MGLTools (Required for MolKit and Kollman charge assignment)
- Biopython (Required for CIF to PDB conversion)
- PDB2PQR / PROPKA (Required for receptor protonation state assignment)

Docking Engine:
- AutoDock Vina (Must be accessible in your system PATH)

================================================================================
================================================================================
STEP-BY-STEP USAGE GUIDE
================================================================================

STEP 1: PREPARE LIGANDS
Open the "docking_list.smi" file. Paste your ligands in this exact format:
[SMILES_STRING]   [TAB]   [LIGAND_IDENTIFIER]
Do not leave empty rows between molecules.

STEP 2: PROTONATION
Run the protonation script in your terminal:
> python set_pH.py
This will use Dimorphite-DL to generate the dominant protonation states at the 
physiological or target pH and output them to "docking_list_pH.smi".

STEP 3: 3D COORDINATE GENERATION
Run the 3D generation script:
> python generate_pdb.py
This uses RDKit's ETKDGv3 algorithm to robustly embed the 3D coordinates, 
minimize the energy, and save the .pdb files to the output directory.

STEP 4: RECEPTOR PREPARATION
Prepare your target protein by pasting the preparation command into your terminal:
> bash 1_prep.sh
This will clean the receptor and convert it to the required .pdbqt format.

STEP 5: CONFIGURATION
Open "config.txt". You must update the Grid Box parameters (center_x, center_y, 
center_z, size_x, size_y, size_z) to match your specific target's binding pocket. 
You can also adjust the CPU cores and exhaustiveness here.

STEP 6: BATCH DOCKING
Execute the docking run:
> python dock_ligands.py
This script will automatically convert your ligand PDBs into Gasteiger-charged 
PDBQT files and feed them into AutoDock Vina based on your config file.

STEP 7: ANALYZE RESULTS
Extract all binding affinities automatically:
> python analyze_docking.py
This will parse the Vina log files and generate a "docking_summary.csv" file 
ranking your ligands by their best binding scores (kcal/mol).

STEP 8: SCAFFOLD CLUSTERING (OPTIONAL)
Group your docked hits by their core chemical structures (Bemis-Murcko scaffolds):
> python cluster_scaffolds.py
This script will cross-reference your docking scores with their chemical topology 
and output "scaffold_clusters.csv". This allows you to easily identify which 
distinct chemical families yielded the best binding affinities, preventing you 
from only analyzing slight variations of a single chemotype.

================================================================================
End of README