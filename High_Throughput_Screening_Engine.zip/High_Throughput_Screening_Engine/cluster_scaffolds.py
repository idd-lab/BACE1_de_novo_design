import os
import sys
import pandas as pd

# Try importing RDKit
try:
    from rdkit import Chem
    from rdkit.Chem.Scaffolds import MurckoScaffold
except ImportError:
    print("Error: RDKit not found. Please run this in your cheminformatics environment.")
    sys.exit(1)

# Define paths
smiles_file = "docking_list_pH.smi"
results_file = "docking_results/docking_summary.csv"
output_file = "docking_results/scaffold_clusters.csv"

def main():
    print("--- Starting Scaffold Clustering ---")
    
    # 1. Check if required files exist
    if not os.path.exists(smiles_file):
        print(f"Error: Could not find {smiles_file}")
        return
    if not os.path.exists(results_file):
        print(f"Error: Could not find {results_file}. Did you run analyze_docking.py?")
        return

    # 2. Read the SMILES data
    smiles_data = []
    with open(smiles_file, 'r') as f:
        for line in f:
            if not line.strip(): continue
            parts = line.strip().split()
            if len(parts) >= 2:
                smiles_data.append({"Ligand": parts[1], "SMILES": parts[0]})
    
    df_smiles = pd.DataFrame(smiles_data)
    
    # 3. Read the Docking Results
    df_results = pd.read_csv(results_file)
    
    # Merge dataframes on Ligand name
    df_merged = pd.merge(df_results, df_smiles, on="Ligand", how="inner")
    
    if df_merged.empty:
        print("Error: No matching ligands found between SMILES list and docking results.")
        return

    # 4. Compute Bemis-Murcko Scaffolds
    print("Extracting core scaffolds using RDKit...")
    scaffolds = []
    for smi in df_merged['SMILES']:
        try:
            mol = Chem.MolFromSmiles(smi)
            if mol:
                # Extract the core scaffold (removes sidechains)
                core = MurckoScaffold.MurckoScaffoldSmiles(mol=mol, includeChirality=False)
                scaffolds.append(core if core else "No_Rings/Linear")
            else:
                scaffolds.append("Parse_Error")
        except Exception:
            scaffolds.append("Parse_Error")
            
    df_merged['Core_Scaffold'] = scaffolds
    
    # 5. Group and Sort
    # Sort primarily by Scaffold, then by Best Docking Score within that scaffold
    df_sorted = df_merged.sort_values(by=["Core_Scaffold", "Best Docking Score"], ascending=[True, True])
    
    # 6. Save the output
    df_sorted.to_csv(output_file, index=False)
    
    # Count unique scaffolds
    unique_scaffolds = df_sorted['Core_Scaffold'].nunique()
    
    print(f"\n✅ Success! Clustered {len(df_sorted)} compounds into {unique_scaffolds} unique chemical families.")
    print(f"Results saved to: {output_file}")
    print("\nTip: Open the CSV to see compounds grouped by their core structure!")

if __name__ == "__main__":
    main()