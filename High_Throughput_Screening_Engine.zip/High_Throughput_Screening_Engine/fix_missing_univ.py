import sys
from pdbfixer import PDBFixer
from openmm.app import PDBFile

infile = sys.argv[1]
outfile = sys.argv[2]

print(f"Fixing topology for {infile}...")
fixer = PDBFixer(filename=infile)
fixer.findMissingResidues()
fixer.findMissingAtoms()
fixer.addMissingAtoms()
PDBFile.writeFile(fixer.topology, fixer.positions, open(outfile, 'w'))