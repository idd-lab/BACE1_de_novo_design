import os

def remove_duplicates(input_file_path, output_file_path):
    """
    Reads a file, removes duplicate lines, and writes the unique lines to a new file.
    """
    seen_lines = set()
    unique_count = 0
    duplicate_count = 0
    
    # Create the output directory if it doesn't exist
    output_dir = os.path.dirname(output_file_path)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        print(f"Created directory: {output_dir}")

    print(f"Reading from: {input_file_path}")
    
    try:
        with open(input_file_path, 'r') as infile:
            lines = infile.readlines()
            
        print(f"Found {len(lines)} lines in the input file.")
        
        with open(output_file_path, 'w') as outfile:
            for line in lines:
                # Use .strip() to remove leading/trailing whitespace and newline characters
                clean_line = line.strip()
                if clean_line:  # Ensure the line is not empty
                    if clean_line not in seen_lines:
                        outfile.write(line)
                        seen_lines.add(clean_line)
                        unique_count += 1
                    else:
                        duplicate_count += 1
                        
        print(f"Done. Found {unique_count} unique lines and {duplicate_count} duplicate lines.")
        print(f"Unique lines saved to: {output_file_path}")
        
    except FileNotFoundError:
        print(f"Error: The file '{input_file_path}' was not found.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == '__main__':
    # Define the file paths for your Ubuntu/miniconda environment
    # Note: Using /mnt/c/ for Windows Subsystem for Linux (WSL)
    input_file = 'docking_list.smi'
    output_file = 'docking_list_filtered.smi'

    # Run the function
    remove_duplicates(input_file, output_file)