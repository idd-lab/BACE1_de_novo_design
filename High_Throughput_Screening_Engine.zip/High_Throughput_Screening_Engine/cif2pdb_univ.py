import sys
import warnings
from Bio.PDB import MMCIFParser, PDBIO
from Bio.PDB.PDBExceptions import PDBConstructionWarning

infile = sys.argv[1]
outfile = sys.argv[2]

print(f"Biopython: Converting {infile} to {outfile}...")

# Suppress minor structural warnings to keep your terminal clean
with warnings.catch_warnings():
    warnings.simplefilter('ignore', PDBConstructionWarning)
    
    # Parse the CIF file
    parser = MMCIFParser()
    structure = parser.get_structure("protein", infile)
    
    # Write exactly as a standard PDB
    io = PDBIO()
    io.set_structure(structure)
    io.save(outfile)
    
print(f"Success! Converted structure saved to {outfile}")