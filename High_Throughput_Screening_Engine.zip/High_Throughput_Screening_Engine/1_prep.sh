#!/bin/bash
# ==========================================
# 1_prep.sh: STRUCTURAL PREPARATION
# ==========================================
export PROT="6ZY5"
export RAW_PDB="6ZY5.pdb"

echo "Starting Structural Prep for ${PROT}..."

# Fix topology
python3 fix_missing_univ.py ${RAW_PDB} ${PROT}_fixed.pdb

# PropKa Protonation
python3 -m pdb2pqr --ff=AMBER --titration-state-method=propka --with-ph=6.92 --keep-chain --noopt ${PROT}_fixed.pdb ${PROT}_protonated.pqr

# Strict PDB conversion
python3 pqr2pdb_univ.py ${PROT}_protonated.pqr ${PROT}_clean.pdb

# Assign Kollman Charges
MGL_PY="/home/yourusername/miniconda3/envs/mgltools_env/bin/python"
$MGL_PY assign_kollman_univ.py ${PROT}_clean.pdb ${PROT}.pdbqt

echo "Preparation complete! Output generated: ${PROT}.pdbqt"
echo "ACTION REQUIRED: Manually process and append your HEME/cofactors to ${PROT}.pdbqt before running 2_dock.sh."