import sys

infile = sys.argv[1]
outfile = sys.argv[2]

print(f"Converting {infile} to {outfile}...")
with open(infile, 'r') as fin, open(outfile, 'w') as fout:
    for line in fin:
        if line.startswith('ATOM') or line.startswith('HETATM'):
            record, serial, name, resName = line[0:6], line[6:11], line[12:16], line[17:20]
            chainID, resSeq = line[21], line[22:26]
            x, y, z = line[30:38], line[38:46], line[46:54]
            fout.write("{:<6}{:>5} {:<4} {:>3} {:1}{:>4}    {}{}{}{:>6.2f}{:>6.2f}\n".format(
                record, serial, name, resName, chainID, resSeq, x, y, z, 1.00, 0.00
            ))
        elif line.startswith('TER'):
            fout.write(line)