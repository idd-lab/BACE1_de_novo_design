import os, sys
from MolKit import Read
from AutoDockTools.MoleculePreparation import AD4ReceptorPreparation

infile = sys.argv[1]
outfile = sys.argv[2]

mols = Read(infile)
mol = mols[0]

RPO = AD4ReceptorPreparation(
    mol, mode='automatic', repairs="", charges_to_add='Kollman', 
    cleanup='nphs', outputfilename=outfile
)